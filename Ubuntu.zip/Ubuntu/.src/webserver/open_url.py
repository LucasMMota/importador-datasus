import webbrowser
import time

time.sleep(3)
webbrowser.open_new_tab('http://127.0.0.1:5000')
